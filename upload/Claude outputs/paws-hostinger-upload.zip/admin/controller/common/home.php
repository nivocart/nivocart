<?php
/**
 * Class ControllerCommonHome
 *
 * @package NivoCart
 */
class ControllerCommonHome extends Controller {
	private $error = [];

	public function index() {
		$this->language->load('common/home');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->document->addStyle('view/javascript/jquery/jqvmap/jqvmap.min.css');

		$this->document->addScript('view/javascript/jquery/jqvmap/jquery.vmap.min.js');

		// Dynamic map selection based on store setting (falls back to world_en)
		$dashboardMap = $this->config->get('config_dashboard_map') ?: 'world_en';
		$mapScripts = [
			'world_en'         => 'maps/jquery.vmap.world.js',
			'europe_en'        => 'maps/jquery.vmap.europe.js',
			'usa_en'           => 'maps/jquery.vmap.usa.js',
			'germany_en'       => 'maps/jquery.vmap.germany.js',
			'algeria_en'       => 'maps/jquery.vmap.algeria.js',
			'argentina_en'     => 'maps/jquery.vmap.argentina.js',
			'brazil_en'        => 'maps/jquery.vmap.brazil.js',
			'canada_en'        => 'maps/jquery.vmap.canada.js',
			'france_en'        => 'maps/jquery.vmap.france.js',
			'greece_en'        => 'maps/jquery.vmap.greece.js',
			'iran_en'          => 'maps/jquery.vmap.iran.js',
			'iraq_en'          => 'maps/jquery.vmap.iraq.js',
			'russia_en'        => 'maps/jquery.vmap.russia.js',
			'tunisia_en'       => 'maps/jquery.vmap.tunisia.js',
			'turkey_en'        => 'maps/jquery.vmap.turkey.js',
			'africa_en'        => 'maps/continents/jquery.vmap.africa.js',
			'asia_en'          => 'maps/continents/jquery.vmap.asia.js',
			'australia_en'     => 'maps/continents/jquery.vmap.australia.js',
			'north-america_en' => 'maps/continents/jquery.vmap.north-america.js',
			'south-america_en' => 'maps/continents/jquery.vmap.south-america.js',
		];

		$mapScript = $mapScripts[$dashboardMap] ?? 'maps/jquery.vmap.world.js';

		$this->document->addScript('view/javascript/jquery/jqvmap/' . $mapScript);

		$this->data['dashboard_map'] = $dashboardMap;

		$this->document->addScript('view/javascript/jquery/flot/jquery.flot.min.js');
		$this->document->addScript('view/javascript/jquery/flot/jquery.flot.resize.min.js');

		$this->data['heading_title'] = $this->language->get('heading_title');

		$this->data['text_overview'] = $this->language->get('text_overview');
		$this->data['text_statistics'] = $this->language->get('text_statistics');
		$this->data['text_latest'] = $this->language->get('text_latest');
		$this->data['text_order_today'] = $this->language->get('text_order_today');
		$this->data['text_customer_today'] = $this->language->get('text_customer_today');
		$this->data['text_sale_today'] = $this->language->get('text_sale_today');
		$this->data['text_online'] = $this->language->get('text_online');
		$this->data['text_total_sale'] = $this->language->get('text_total_sale');
		$this->data['text_total_sale_year'] = $this->language->get('text_total_sale_year');
		$this->data['text_total_sale_month'] = $this->language->get('text_total_sale_month');
		$this->data['text_total_order'] = $this->language->get('text_total_order');
		$this->data['text_total_customer'] = $this->language->get('text_total_customer');
		$this->data['text_total_customer_approval'] = $this->language->get('text_total_customer_approval');
		$this->data['text_total_review'] = $this->language->get('text_total_review');
		$this->data['text_total_review_approval'] = $this->language->get('text_total_review_approval');
		$this->data['text_total_affiliate'] = $this->language->get('text_total_affiliate');
		$this->data['text_total_affiliate_approval'] = $this->language->get('text_total_affiliate_approval');
		$this->data['text_total_store_products'] = $this->language->get('text_total_store_products');
		$this->data['text_day'] = $this->language->get('text_day');
		$this->data['text_week'] = $this->language->get('text_week');
		$this->data['text_month'] = $this->language->get('text_month');
		$this->data['text_year'] = $this->language->get('text_year');
		$this->data['text_topseller'] = $this->language->get('text_topseller');
		$this->data['text_topview'] = $this->language->get('text_topview');
		$this->data['text_topcustomer'] = $this->language->get('text_topcustomer');
		$this->data['text_topcountry'] = 'Sales by Region';
		$this->data['text_no_results'] = $this->language->get('text_no_results');
		$this->data['text_enabled'] = $this->language->get('text_enabled');
		$this->data['text_disabled'] = $this->language->get('text_disabled');
		$this->data['text_deleted'] = $this->language->get('text_deleted');

		$this->data['help_mail_log'] = $this->language->get('help_mail_log');
		$this->data['help_quote_log'] = $this->language->get('help_quote_log');
		$this->data['help_error_log'] = $this->language->get('help_error_log');
		$this->data['help_seo_url'] = $this->language->get('help_seo_url');

		$this->data['tab_map'] = $this->language->get('tab_map');
		$this->data['tab_order'] = $this->language->get('tab_order');
		$this->data['tab_customer'] = $this->language->get('tab_customer');
		$this->data['tab_review'] = $this->language->get('tab_review');
		$this->data['tab_affiliate'] = $this->language->get('tab_affiliate');
		$this->data['tab_return'] = $this->language->get('tab_return');
		$this->data['tab_upload'] = $this->language->get('tab_upload');

		$this->data['column_order'] = $this->language->get('column_order');
		$this->data['column_customer'] = $this->language->get('column_customer');
		$this->data['column_conversion'] = $this->language->get('column_conversion');
		$this->data['column_status'] = $this->language->get('column_status');
		$this->data['column_date_added'] = $this->language->get('column_date_added');
		$this->data['column_total'] = $this->language->get('column_total');
		$this->data['column_firstname'] = $this->language->get('column_firstname');
		$this->data['column_lastname'] = $this->language->get('column_lastname');
		$this->data['column_name'] = $this->language->get('column_name');
		$this->data['column_email'] = $this->language->get('column_email');
		$this->data['column_customer_group'] = $this->language->get('column_customer_group');
		$this->data['column_orders_passed'] = $this->language->get('column_orders_passed');
		$this->data['column_orders_missed'] = $this->language->get('column_orders_missed');
		$this->data['column_product'] = $this->language->get('column_product');
		$this->data['column_model'] = $this->language->get('column_model');
		$this->data['column_author'] = $this->language->get('column_author');
		$this->data['column_rating'] = $this->language->get('column_rating');
		$this->data['column_rating_total'] = $this->language->get('column_rating_total');
		$this->data['column_affiliate'] = $this->language->get('column_affiliate');
		$this->data['column_tracking'] = $this->language->get('column_tracking');
		$this->data['column_balance'] = $this->language->get('column_balance');
		$this->data['column_approved'] = $this->language->get('column_approved');
		$this->data['column_return_id'] = $this->language->get('column_return_id');
		$this->data['column_return_history'] = $this->language->get('column_return_history');
		$this->data['column_upload_id'] = $this->language->get('column_upload_id');
		$this->data['column_filename'] = $this->language->get('column_filename');
		$this->data['column_action'] = $this->language->get('column_action');

		$this->data['entry_range'] = $this->language->get('entry_range');

		// Login unserialize warning
		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}

		// Delete install directory
		if (is_dir(dirname(DIR_APPLICATION) . '/install')) {
			$this->load->model('tool/system');

			$this->model_tool_system->deleteDirectory('../install');

			clearstatcache();
		}

		// Check image directory is writeable
		$file = DIR_IMAGE . 'test';
		$handle = fopen($file, 'a+');
		fwrite($handle, '');
		fclose($handle);

		if (!file_exists($file)) {
			$this->data['error_image'] = sprintf($this->language->get('error_image'), DIR_IMAGE);
		} else {
			$this->data['error_image'] = '';

			unlink($file);
		}

		// Check image cache directory is writeable
		$file = DIR_IMAGE . 'cache/test';
		$handle = fopen($file, 'a+');
		fwrite($handle, '');
		fclose($handle);

		if (!file_exists($file)) {
			$this->data['error_image_cache'] = sprintf($this->language->get('error_image_cache'), DIR_IMAGE . 'cache/');
		} else {
			$this->data['error_image_cache'] = '';

			unlink($file);
		}

		// Check cache directory is writeable
		$file = DIR_CACHE . 'test';
		$handle = fopen($file, 'a+');
		fwrite($handle, '');
		fclose($handle);

		if (!file_exists($file)) {
			$this->data['error_cache'] = sprintf($this->language->get('error_cache'), DIR_CACHE);
		} else {
			$this->data['error_cache'] = '';

			unlink($file);
		}

		// Check download directory is writeable
		$file = DIR_DOWNLOAD . 'test';
		$handle = fopen($file, 'a+');
		fwrite($handle, '');
		fclose($handle);

		if (!file_exists($file)) {
			$this->data['error_download'] = sprintf($this->language->get('error_download'), DIR_DOWNLOAD);
		} else {
			$this->data['error_download'] = '';

			unlink($file);
		}

		// Check upload directory is writeable
		$file = DIR_UPLOAD . 'test';
		$handle = fopen($file, 'a+');
		fwrite($handle, '');
		fclose($handle);

		if (!file_exists($file)) {
			$this->data['error_upload'] = sprintf($this->language->get('error_upload'), DIR_UPLOAD);
		} else {
			$this->data['error_upload'] = '';

			unlink($file);
		}

		// Check logs directory is writeable
		$file = DIR_LOGS . 'test';
		$handle = fopen($file, 'a+');
		fwrite($handle, '');
		fclose($handle);

		if (!file_exists($file)) {
			$this->data['error_logs'] = sprintf($this->language->get('error_logs'), DIR_LOGS);
		} else {
			$this->data['error_logs'] = '';

			unlink($file);
		}

		// Check user log number of entries
		$this->load->model('user/user_log');

		$this->data['text_user_log'] = $this->language->get('text_user_log');

		$entries_total = $this->model_user_user_log->getTotalDataLog();

		if ($entries_total > 499) {
			$this->data['error_user_log'] = sprintf($this->language->get('error_user_log'), (int)$entries_total);
			$this->data['view_user_log'] = $this->url->link('user/user_log', 'token=' . $this->session->data['token'], 'SSL');
		} else {
			$this->data['error_user_log'] = '';
			$this->data['view_user_log'] = '';
		}

		// Error log
		$error_filename = $this->config->get('config_error_filename');

		$error_log_file = DIR_LOGS . $error_filename;

		if (!empty($error_filename) && preg_match('/\.txt$/i', $error_filename) && file_exists($error_log_file)) {
			$this->data['error_log_status'] = file_get_contents($error_log_file, FILE_USE_INCLUDE_PATH, null);
		} else {
			$this->data['error_log_status'] = '';
		}

		$this->data['open_error_log'] = $this->url->link('tool/error_log', 'token=' . $this->session->data['token'], 'SSL');

		// Quote log
		$quote_filename = $this->config->get('config_quote_filename');

		$quote_log_file = DIR_LOGS . $quote_filename;

		if (!empty($quote_filename) && preg_match('/\.txt$/i', $quote_filename) && file_exists($quote_log_file)) {
			$this->data['quote_log_status'] = file_get_contents($quote_log_file, FILE_USE_INCLUDE_PATH, null);
		} else {
			$this->data['quote_log_status'] = '';
		}

		$this->data['open_quote_log'] = $this->url->link('tool/quote_log', 'token=' . $this->session->data['token'], 'SSL');

		// Email log
		$mail_filename = $this->config->get('config_mail_filename');

		$mail_log_file = DIR_LOGS . $mail_filename;

		if (!empty($mail_filename) && preg_match('/\.txt$/i', $mail_filename) && file_exists($mail_log_file)) {
			$this->data['mail_log_status'] = file_get_contents($mail_log_file, FILE_USE_INCLUDE_PATH, null);
		} else {
			$this->data['mail_log_status'] = '';
		}

		$this->data['open_mail_log'] = $this->url->link('tool/mail_log', 'token=' . $this->session->data['token'], 'SSL');

		clearstatcache();

		// Breadcrumbs
		$this->data['breadcrumbs'] = [];

		$this->data['breadcrumbs'][] = [
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
			'separator' => false
		];

		// Session Token
		$this->data['token'] = $this->session->data['token'];

		// Seo urls
		$seo_url_status = $this->config->get('config_seo_url');
		$seo_url_ratio = 0;

		$this->data['error_seo_url'] = '';

		if ($seo_url_status) {
			$this->load->model('tool/seo_url_manager');

			$seo_url_audit = $this->model_tool_seo_url_manager->getAuditSummary();

			if (!$seo_url_audit['total']) {
				$seo_url_ratio = 1;
			} elseif ($seo_url_audit['total'] <= 5) {
				$seo_url_ratio = 2;
			} else {
				$seo_url_ratio = 3;
			}

			if ($seo_url_audit['total']) {
				$this->data['error_seo_url'] = sprintf($this->language->get('error_seo_url'), (int)$seo_url_audit['missing'], (int)$seo_url_audit['duplicate'], (int)$seo_url_audit['mistyped'], (int)$seo_url_audit['orphan']);
			}
		}

		$this->data['text_seo_url_audit'] = $this->language->get('text_seo_url_audit');

		$this->data['seo_url_status'] = $seo_url_status;
		$this->data['seo_url_ratio'] = $seo_url_ratio;

		$this->data['open_seo_url'] = $this->url->link('tool/seo_url_manager', 'token=' . $this->session->data['token'], 'SSL');
		$this->data['open_seo_url_audit'] = $this->url->link('tool/seo_url_manager/audit', 'token=' . $this->session->data['token'], 'SSL');

		// Stylesheet
		$admin_css = $this->config->get('config_admin_stylesheet');

		$this->load->model('design/administration');

		$contrast = $this->model_design_administration->getAdministrationContrastByName($admin_css);

		if ($contrast === 'dark') {
			$this->data['chart_background'] = '#6D7582';
			$this->data['chart_border'] = '#999999';
			$this->data['chart_colour'] = '#E5E5E5';
		} elseif ($contrast === 'light') {
			$this->data['chart_background'] = '#FFFFFF';
			$this->data['chart_border'] = '#AAAAAA';
			$this->data['chart_colour'] = '#333333';
		} else {
			$this->data['chart_background'] = '#FFFFFF';
			$this->data['chart_border'] = '#AAAAAA';
			$this->data['chart_colour'] = '#333333';
		}

		$this->data['admin_css'] = $admin_css;

		// Overview Sales
		$this->load->model('sale/order');

		$sale_all = $this->model_sale_order->getTotalSales([]);
		$sale_year = $this->model_sale_order->getTotalSalesByYear(date('Y'));
		$sale_month = $this->model_sale_order->getTotalSalesByMonth(date('m'));

		$this->data['total_sale'] = $this->currency->format($sale_all, $this->config->get('config_currency'));
		$this->data['total_sale_year'] = $this->currency->format($sale_year, $this->config->get('config_currency'));
		$this->data['total_sale_month'] = $this->currency->format($sale_month, $this->config->get('config_currency'));

		// Overview Customers
		$this->load->model('sale/customer');

		$this->data['total_customer'] = $this->model_sale_customer->getTotalCustomers([]);
		$this->data['total_customer_approval'] = $this->model_sale_customer->getTotalCustomersAwaitingApproval();

		// Overview Reviews
		$this->load->model('catalog/review');

		$this->data['total_review'] = $this->model_catalog_review->getTotalReviews();
		$this->data['total_review_approval'] = $this->model_catalog_review->getTotalReviewsAwaitingApproval();

		// Overview Affiliates
		$this->load->model('sale/affiliate');

		$this->data['total_affiliate'] = $this->model_sale_affiliate->getTotalAffiliates([]);
		$this->data['total_affiliate_approval'] = $this->model_sale_affiliate->getTotalAffiliatesAwaitingApproval();
		$this->data['allow_affiliate'] = $this->config->get('config_affiliate_disable') ? false : true;

		// Overview Store Products
		$this->load->model('report/product');

		$this->data['total_store_products'] = $this->model_report_product->getTotalProducts([]);

		// Overview Returns
		$this->load->model('sale/return');

		$this->data['total_return'] = $this->model_sale_return->getTotalReturns([]);
		$this->data['allow_return'] = $this->config->get('config_return_disable') ? false : true;

		// Overview Uploads
		$this->load->model('tool/upload');

		$this->data['total_upload'] = $this->model_tool_upload->getTotalUploads([]);

		// Overview Links
		$config_order_status_id = $this->config->get('config_order_status_id');
		$config_complete_status_id = $this->config->get('config_complete_status_id');

		if ($config_order_status_id != $config_complete_status_id) {
			$this->data['total_pending_orders'] = $this->model_sale_order->getTotalOrdersByOrderStatusId($config_order_status_id);
		} else {
			$this->data['total_pending_orders'] = 0;
		}

		$this->data['view_reviews'] = $this->url->link('catalog/review', 'token=' . $this->session->data['token'], 'SSL');
		$this->data['view_affiliates'] = $this->url->link('sale/affiliate', 'token=' . $this->session->data['token'], 'SSL');

		// Today - New Orders
		$this->data['total_order'] = $this->model_sale_order->getTotalOrders([]);

		$order_today = $this->model_sale_order->getTotalOrders(['filter_date_added' => date('Y-m-d')]);

		$this->data['total_order_today'] = ((int)$order_today > 0) ? (int)$order_today : 0;

		$this->data['view_orders'] = $this->url->link('sale/order', 'token=' . $this->session->data['token'], 'SSL');

		// Today - New Customers
		$customer_today = $this->model_sale_customer->getTotalCustomers(['filter_date_added' => date('Y-m-d')]);

		$this->data['total_customer_today'] = ($customer_today > 0) ? $customer_today : 0;

		$this->data['view_customers'] = $this->url->link('sale/customer', 'token=' . $this->session->data['token'], 'SSL');

		// Today - New Sales
		$this->load->model('report/sale');

		$total_sales_today = $this->model_report_sale->getTotalSales(['filter_date_added' => date('Y-m-d')]);

		$this->data['total_sale_today'] = $this->currency->format($total_sales_today, $this->config->get('config_currency'));

		$this->data['view_sales'] = $this->url->link('report/sale_order', 'token=' . $this->session->data['token'] . '&filter_date_start=' . date('Y-m-d', strtotime(date('Y') . '-' . date('m') . '-01')) . '&filter_date_end=' . date('Y-m-d') . '&filter_group=day', 'SSL');

		// Today - Visitors Online
		$this->load->model('report/online');

		$this->data['total_online'] = $this->model_report_online->getTotalCustomersOnline([]);

		$this->data['view_online'] = $this->url->link('report/customer_online', 'token=' . $this->session->data['token'], 'SSL');

		$this->data['show_dob'] = $this->config->get('config_customer_dob');

		// Tab Map - Sales by Region/Zone for the top country (payment address)
		$this->load->model('report/sale');

		$this->data['top_countries'] = [];
		$this->data['top_flag'] = '';

		// Find the #1 country by sales value (now also returns country_name)
		$top_country_results = $this->model_report_sale->getTopOrdersByCountry(1);
		$top_country = $top_country_results[0] ?? null;

		if ($top_country && !empty($top_country['iso_code_2'])) {
			$iso = $top_country['iso_code_2'];
			$country_total = (float)$top_country['amount'];

			// Look up the country name for the heading
			$country_name_row = $this->db->query("SELECT name FROM `" . DB_PREFIX . "country` WHERE iso_code_2 = '" . $this->db->escape($iso) . "' LIMIT 1");
			$country_name = $country_name_row->row['name'] ?? $iso;

			// Override heading to show the country name dynamically
			$this->data['text_topcountry'] = $country_name . ' — by Region';

			// Restore the country flag for the top country
			$this->data['top_flag'] = 'view/image/flags/' . strtolower($iso) . '.png';

			// Get payment-address zone breakdown for that country
			$zone_results = $this->model_report_sale->getTopOrdersByZone($iso);

			foreach ($zone_results as $zone_row) {
				// Note: rounding mode PHP_ROUND_HALF_UP required for PHP 8.4+
				$circle_percent = ($country_total > 0) ? round((float)$zone_row['amount'] / $country_total, 4, PHP_ROUND_HALF_UP) : 0;

				$this->data['top_countries'][] = [
					'amount'  => $circle_percent,
					'country' => $zone_row['zone_name']
				];
			}
		}

		// Tab Orders
		$this->data['orders'] = [];

		$data = [
			'sort'  => 'o.date_added',
			'order' => 'DESC',
			'start' => 0,
			'limit' => 10
		];

		$results = $this->model_sale_order->getOrders($data);

		foreach ($results as $result) {
			$action = [];

			$action[] = [
				'text' => $this->language->get('text_view'),
				'href' => $this->url->link('sale/order/info', 'token=' . $this->session->data['token'] . '&order_id=' . $result['order_id'], 'SSL')
			];

			$customer_group = $this->model_sale_customer->getOrdersCustomersGroup($result['customer_id']);

			$orders_total = $this->model_sale_customer->getTotalCustomersOrders($result['customer_id']);
			$orders_missed = $this->model_sale_customer->getTotalCustomersOrdersMissed($result['customer_id']);

			$orders_passed = $orders_total - $orders_missed;
			$orders_conversion = ($orders_passed * 100) / $orders_total;

			$this->data['orders'][] = [
				'order_id'       => $result['order_id'],
				'customer'       => $result['customer'],
				'customer_group' => $result['customer_id'] ? $customer_group : $this->language->get('text_guest'),
				'passed'         => ((int)$orders_passed > 0) ? '<span class="passed">' . (int)$orders_passed . '</span>' : '<span class="disabled">' . (int)$orders_passed . '</span>',
				'missed'         => ((int)$orders_missed > 0) ? '<span class="missed">' . (int)$orders_missed . '</span>' : '<span class="disabled">' . (int)$orders_missed . '</span>',
				'conversion'     => round($orders_conversion, 2, PHP_ROUND_HALF_UP) . '%',
				'date_added'     => date($this->language->get('date_format_time'), strtotime($result['date_added'])),
				'status'         => $result['status'],
				'total'          => $this->currency->format($result['total'], $result['currency_code'], $result['currency_value'], true),
				'action'         => $action
			];
		}

		// Tab Customers
		$this->data['customers'] = [];

		$data = [
			'sort'  => 'c.date_added',
			'order' => 'DESC',
			'start' => 0,
			'limit' => 10
		];

		$customer_results = $this->model_sale_customer->getCustomers($data);

		foreach ($customer_results as $customer_result) {
			$action = [];

			$action[] = [
				'text' => $this->language->get('text_edit'),
				'href' => $this->url->link('sale/customer/update', 'token=' . $this->session->data['token'] . '&customer_id=' . (int)$customer_result['customer_id'], 'SSL')
			];

			$action_passed = [];

			$action_passed[] = [
				'text' => $this->language->get('text_view'),
				'href' => $this->url->link('sale/order', 'token=' . $this->session->data['token'] . '&filter_email=' . (string)$customer_result['email'] . '&filter_customer=' . (string)$customer_result['name'], 'SSL')
			];

			$action_missed = [];

			$action_missed[] = [
				'text' => $this->language->get('text_view'),
				'href' => $this->url->link('sale/order', 'token=' . $this->session->data['token'] . '&filter_email=' . (string)$customer_result['email'] . '&filter_order_status_id=0', 'SSL')
			];

			if ($this->config->get('config_customer_dob')) {
				$customer_age = date_diff(date_create($customer_result['date_of_birth']), date_create('today'))->y;
			} else {
				$customer_age = '';
			}

			$customer_deleted = $this->model_sale_customer->checkCustomersDeletedId($customer_result['customer_id']);

			$this->data['customers'][] = [
				'customer_id'    => $customer_result['customer_id'],
				'name'           => $customer_result['name'],
				'age'            => $customer_age,
				'email'          => $customer_result['email'],
				'customer_group' => $customer_result['customer_group'] ? $customer_result['customer_group'] : $this->language->get('text_guest'),
				'approved'       => $customer_result['approved'] ? $this->language->get('text_yes') : $this->language->get('text_no'),
				'status'         => ($customer_deleted) ? 2 : $customer_result['status'],
				'date_added'     => date($this->language->get('date_format_short'), strtotime($customer_result['date_added'])),
				'orders_passed'  => $this->model_sale_customer->getTotalCustomersOrders($customer_result['customer_id']),
				'orders_missed'  => $this->model_sale_customer->getTotalCustomersOrdersMissed($customer_result['customer_id']),
				'action_passed'  => $action_passed,
				'action_missed'  => $action_missed,
				'action'         => $action
			];
		}

		// Tab Reviews
		$this->data['reviews'] = [];

		$data = [
			'sort'  => 'r.date_added',
			'order' => 'DESC',
			'start' => 0,
			'limit' => 10
		];

		$review_results = $this->model_catalog_review->getReviews($data);

		foreach ($review_results as $review_result) {
			$action = [];

			$action[] = [
				'text' => $this->language->get('text_edit'),
				'href' => $this->url->link('catalog/review/update', 'token=' . $this->session->data['token'] . '&review_id=' . (int)$review_result['review_id'], 'SSL')
			];

			$action_rated = [];

			$action_rated[] = [
				'text' => $this->language->get('text_view'),
				'href' => $this->url->link('catalog/review', 'token=' . $this->session->data['token'] . '&filter_review=' . (int)$review_result['review_id'] . '&filter_order_status_id=0', 'SSL')
			];

			$this->data['reviews'][] = [
				'review_id'    => $review_result['review_id'],
				'name'         => $review_result['name'],
				'author'       => $review_result['author'],
				'rating'       => $review_result['rating'],
				'status'       => $review_result['status'],
				'date_added'   => date($this->language->get('date_format_time'), strtotime($review_result['date_added'])),
				'rating_total' => $this->model_catalog_review->getTotalProductReviews($review_result['product_id']),
				'action_rated' => $action_rated,
				'action'       => $action
			];
		}

		// Tab Affiliates
		$this->data['affiliates'] = [];

		$data = [
			'sort'  => 'a.date_added',
			'order' => 'DESC',
			'start' => 0,
			'limit' => 10
		];

		$affiliate_results = $this->model_sale_affiliate->getAffiliates($data);

		foreach ($affiliate_results as $affiliate_result) {
			$action = [];

			$action[] = [
				'text' => $this->language->get('text_edit'),
				'href' => $this->url->link('sale/affiliate/update', 'token=' . $this->session->data['token'] . '&affiliate_id=' . (int)$affiliate_result['affiliate_id'], 'SSL')
			];

			$this->data['affiliates'][] = [
				'affiliate_id' => $affiliate_result['affiliate_id'],
				'name'         => $affiliate_result['name'],
				'email'        => $affiliate_result['email'],
				'code'         => $affiliate_result['code'],
				'balance'      => $this->currency->format($affiliate_result['balance'], $this->config->get('config_currency')),
				'status'       => $affiliate_result['status'],
				'approved'     => $affiliate_result['approved'] ? $this->language->get('text_yes') : $this->language->get('text_no'),
				'date_added'   => date($this->language->get('date_format_short'), strtotime($affiliate_result['date_added'])),
				'action'       => $action
			];
		}

		// Tab Returns
		$this->data['returns'] = [];

		$data = [
			'sort'  => 'r.date_added',
			'order' => 'DESC',
			'start' => 0,
			'limit' => 10
		];

		$return_results = $this->model_sale_return->getReturns($data);

		foreach ($return_results as $return_result) {
			$action = [];

			$action[] = [
				'text' => $this->language->get('text_view'),
				'href' => $this->url->link('sale/return/info', 'token=' . $this->session->data['token'] . '&return_id=' . (int)$return_result['return_id'], 'SSL')
			];

			$action[] = [
				'text' => $this->language->get('text_edit'),
				'href' => $this->url->link('sale/return/update', 'token=' . $this->session->data['token'] . '&return_id=' . (int)$return_result['return_id'], 'SSL')
			];

			$action_return = [];

			$action_return[] = [
				'text' => $this->language->get('text_view'),
				'href' => $this->url->link('sale/return', 'token=' . $this->session->data['token'] . '&filter_email=' . (string)$return_result['email'], 'SSL')
			];

			$this->data['returns'][] = [
				'return_id'      => $return_result['return_id'],
				'order_id'       => $return_result['order_id'],
				'customer'       => $return_result['customer'],
				'product'        => $return_result['product'],
				'status'         => $return_result['status'],
				'date_added'     => date($this->language->get('date_format_time'), strtotime($return_result['date_added'])),
				'return_history' => $this->model_sale_customer->getTotalCustomersReturns($return_result['customer_id']),
				'action_return'  => $action_return,
				'action'         => $action
			];
		}

		// Tab Uploads
		$this->data['uploads'] = [];

		$data = [
			'sort'  => 'date_added',
			'order' => 'DESC',
			'start' => 0,
			'limit' => 10
		];

		$upload_results = $this->model_tool_upload->getUploads($data);

		foreach ($upload_results as $upload_result) {
			$action = [];

			$action[] = [
				'text' => $this->language->get('text_download'),
				'href' => $this->url->link('tool/upload/download', 'token=' . $this->session->data['token'] . '&code=' . $upload_result['code'], 'SSL')
			];

			$this->data['uploads'][] = [
				'upload_id'  => $upload_result['upload_id'],
				'name'       => $upload_result['name'],
				'filename'   => $upload_result['filename'],
				'date_added' => date($this->language->get('date_format_time'), strtotime($upload_result['date_added'])),
				'action'     => $action
			];
		}

		// Data for Top 5 Reports
		$data_reports = [
			'order' => 'DESC',
			'start' => 0,
			'limit' => 5
		];

		// Best Seller report
		$this->language->load('report/product_purchased');

		$this->load->model('report/product');

		$this->data['sellers'] = [];

		$purchased_results = [];

		$purchased_results = $this->model_report_product->getPurchased($data_reports);

		foreach ($purchased_results as $purchased_result) {
			$product_purchased_length = mb_strlen($purchased_result['name'], 'UTF-8');

			if ($product_purchased_length > 24) {
				$product_purchased = mb_substr(strip_tags($purchased_result['name']), 0, 24, 'UTF-8') . '..';
			} else {
				$product_purchased = $purchased_result['name'];
			}

			$model_purchased_length = mb_strlen($purchased_result['model'], 'UTF-8');

			if ($model_purchased_length > 12) {
				$model_purchased = mb_substr(strip_tags($purchased_result['model']), 0, 12, 'UTF-8') . '..';
			} else {
				$model_purchased = $purchased_result['model'];
			}

			$this->data['sellers'][] = [
				'name'     => $product_purchased,
				'model'    => $model_purchased,
				'quantity' => $purchased_result['quantity'],
				'total'    => $this->currency->format($purchased_result['total'], $this->config->get('config_currency')),
				'href'     => $this->url->link('catalog/product/update', 'token=' . $this->session->data['token'] . '&product_id=' . $purchased_result['product_id'], 'SSL')
			];
		}

		// Most Viewed report
		$this->language->load('report/product_viewed');

		$this->load->model('report/product');

		$this->data['views'] = [];

		$product_views_total = $this->model_report_product->getTotalProductViews();

		$viewed_results = [];

		$viewed_results = $this->model_report_product->getProductsViewed($data_reports);

		foreach ($viewed_results as $viewed_result) {
			$product_viewed_length = mb_strlen($viewed_result['name'], 'UTF-8');

			if ($product_viewed_length > 24) {
				$product_viewed = mb_substr(strip_tags($viewed_result['name']), 0, 24, 'UTF-8') . '..';
			} else {
				$product_viewed = $viewed_result['name'];
			}

			$model_viewed_length = mb_strlen($viewed_result['model'], 'UTF-8');

			if ($model_viewed_length > 12) {
				$model_viewed = mb_substr(strip_tags($viewed_result['model']), 0, 12, 'UTF-8') . '..';
			} else {
				$model_viewed = $viewed_result['model'];
			}

			if ($viewed_result['viewed']) {
				// Note: rounding mode PHP_ROUND_HALF_UP required for PHP 8.4+
				$percent = round((($viewed_result['viewed'] * 100) / $product_views_total), 1, PHP_ROUND_HALF_UP);
			} else {
				$percent = 0;
			}

			$this->data['views'][] = [
				'name'    => $product_viewed,
				'model'   => $model_viewed,
				'viewed'  => $viewed_result['viewed'],
				'percent' => $percent . '%',
				'href'    => $this->url->link('catalog/product/update', 'token=' . $this->session->data['token'] . '&product_id=' . (int)$viewed_result['product_id'], 'SSL')
			];
		}

		// Best Customer report
		$this->language->load('report/customer_order');

		$this->load->model('report/customer');

		$this->data['clients'] = [];

		$client_results = $this->model_report_customer->getOrders($data_reports);

		foreach ($client_results as $client_result) {
			$client_length = mb_strlen($client_result['customer'], 'UTF-8');

			if ($client_length > 24) {
				$client = mb_substr(strip_tags($client_result['customer']), 0, 24, 'UTF-8') . '..';
			} else {
				$client = $client_result['customer'];
			}

			$this->data['clients'][] = [
				'customer' => $client,
				'orders'   => $client_result['orders'],
				'products' => $client_result['products'],
				'total'    => $this->currency->format($client_result['total'], $this->config->get('config_currency')),
				'href'     => $this->url->link('sale/customer/update', 'token=' . $this->session->data['token'] . '&customer_id=' . (int)$client_result['customer_id'], 'SSL')
			];
		}

		// Currency auto-update
		if ($this->config->get('config_currency_auto') && extension_loaded('curl')) {
			$this->load->model('localisation/currency');

			if ($this->config->get('config_alpha_vantage')) {
				$this->model_localisation_currency->updateAlphaVantageCurrencies();
			} else {
				$this->model_localisation_currency->updateCurrencies();
			}
		}

		// Optional dashboard template per admin theme (e.g. home_nova.tpl), falls back to home.tpl
		$this->template = 'common/home.tpl';

		$theme_template = preg_replace('/[^a-z0-9_]/', '', strtolower((string)$admin_css));

		$dashboard_template = $theme_template;

		if (in_array($theme_template, ['dark', 'light']) && !is_file(DIR_TEMPLATE . 'common/home_' . $theme_template . '.tpl')) {
			$dashboard_template = 'nova';
		}

		if ($dashboard_template && is_file(DIR_TEMPLATE . 'common/home_' . $dashboard_template . '.tpl')) {
			$this->novaData([
				'sale_all'         => $sale_all,
				'sale_year'        => $sale_year,
				'sale_month'       => $sale_month,
				'sale_today'       => $total_sales_today,
				'seo_url_issues'   => isset($seo_url_audit['total']) ? (int)$seo_url_audit['total'] : 0
			]);

			$this->document->addScript('view/javascript/nova/nc-nova.js');

			$this->template = 'common/home_' . $dashboard_template . '.tpl';
		}

		$this->children = [
			'common/header',
			'common/footer'
		];

		$this->response->setOutput($this->render());
	}

	/**
	 * Extra values used by the dashboard templates that draw gauges, counters and bars.
	 * Only called when the active admin theme has its own home template.
	 *
	 * @param array $raw Unformatted numbers already calculated by index()
	 */
	private function novaData($raw) {
		$this->language->load('common/home');

		$text_keys = [
			'text_vs_yesterday', 'text_store_health', 'text_overall', 'text_orders_hour', 'text_avg_order',
			'text_system_status', 'text_moderation', 'text_orders_by_hour', 'text_live',
			'text_pending_orders', 'text_awaiting_approval', 'text_seo_issues', 'text_directories',
			'text_customers_approved', 'text_reviews_approved', 'text_affiliates_approved', 'text_orders_processed',
			'text_seo_healthy',
			'column_sold', 'column_viewed', 'column_percent',
			'column_orders', 'column_products'
		];

		foreach ($text_keys as $key) {
			$this->data[$key] = $this->language->get($key);
		}

		$currency = $this->config->get('config_currency');

		// Counter formatting for money values
		$this->data['money_prefix'] = $this->currency->getSymbolLeft($currency);
		$this->data['money_suffix'] = $this->currency->getSymbolRight($currency);
		$this->data['money_decimals'] = (int)$this->currency->getDecimalPlace($currency);

		$this->data['raw_sale'] = round((float)$raw['sale_all'], 2);
		$this->data['raw_sale_year'] = round((float)$raw['sale_year'], 2);
		$this->data['raw_sale_month'] = round((float)$raw['sale_month'], 2);
		$this->data['raw_sale_today'] = round((float)$raw['sale_today'], 2);

		// Yesterday comparison for the three KPI tiles
		$yesterday = date('Y-m-d', strtotime('-1 day'));

		$orders_yesterday = (int)$this->model_sale_order->getTotalOrders(['filter_date_added' => $yesterday]);
		$customers_yesterday = (int)$this->model_sale_customer->getTotalCustomers(['filter_date_added' => $yesterday]);
		$sales_yesterday = (float)$this->model_report_sale->getTotalSales(['filter_date_added' => $yesterday]);

		$this->data['delta_orders'] = $this->novaDelta((int)$this->data['total_order_today'], $orders_yesterday);
		$this->data['delta_customers'] = $this->novaDelta((int)$this->data['total_customer_today'], $customers_yesterday);
		$this->data['delta_sales'] = $this->novaDelta((float)$raw['sale_today'], $sales_yesterday);

		// Orders by hour (today) for the bars widgets
		$hours = array_fill(0, 24, 0);

		$query = $this->db->query("SELECT HOUR(date_added) AS `hour`, COUNT(*) AS `total` FROM `" . DB_PREFIX . "order` WHERE order_status_id > '0' AND DATE(date_added) = DATE(NOW()) GROUP BY HOUR(date_added)");

		foreach ($query->rows as $row) {
			$hours[(int)$row['hour']] = (int)$row['total'];
		}

		$this->data['orders_by_hour'] = json_encode($hours);
		$this->data['orders_by_hour_max'] = max(4, max($hours));
		$this->data['current_hour'] = (int)date('G');
		$this->data['orders_hour_rate'] = round(array_sum($hours) / max(1, (int)date('G') + 1), 1);

		$total_order_today = (int)$this->data['total_order_today'];

		$this->data['avg_order_value'] = ($total_order_today > 0) ? round((float)$raw['sale_today'] / $total_order_today, 2) : 0;

		// Sales by region donut
		$segments = [];

		foreach ($this->data['top_countries'] as $top_country) {
			$segments[] = [
				'label' => html_entity_decode((string)$top_country['country'], ENT_QUOTES, 'UTF-8'),
				'value' => round((float)$top_country['amount'] * 100, 1, PHP_ROUND_HALF_UP)
			];
		}

		$this->data['donut_segments'] = htmlspecialchars(json_encode($segments), ENT_QUOTES, 'UTF-8');

		// Moderation queue and system status ratios (percentages)
		$total_orders = (int)$this->data['total_order'];
		$pending_orders = (int)$this->data['total_pending_orders'];

		$this->data['pct_customers'] = $this->novaRatio((int)$this->data['total_customer'], (int)$this->data['total_customer_approval']);
		$this->data['pct_reviews'] = $this->novaRatio((int)$this->data['total_review'], (int)$this->data['total_review_approval']);
		$this->data['pct_affiliates'] = $this->novaRatio((int)$this->data['total_affiliate'], (int)$this->data['total_affiliate_approval']);
		$this->data['pct_orders'] = $this->novaRatio($total_orders, $pending_orders);

		$awaiting = (int)$this->data['total_customer_approval'] + (int)$this->data['total_review_approval'];

		if ($this->data['allow_affiliate']) {
			$awaiting += (int)$this->data['total_affiliate_approval'];
		}

		$this->data['total_awaiting'] = $awaiting;
		$this->data['seo_url_issues'] = $raw['seo_url_issues'];
		$this->data['pct_seo'] = ($this->data['seo_url_status']) ? max(0, 100 - min(100, $raw['seo_url_issues'] * 5)) : 100;

		// Store health: writeable directories, error log and SEO URLs
		$directory_errors = 0;

		foreach (['error_image', 'error_image_cache', 'error_cache', 'error_download', 'error_upload', 'error_logs'] as $key) {
			if (!empty($this->data[$key])) {
				$directory_errors++;
			}
		}

		$this->data['pct_directories'] = (int)round((6 - $directory_errors) / 6 * 100);

		$health = 100 - ($directory_errors * 15);

		if (!empty($this->data['error_log_status'])) {
			$health -= 10;
		}

		if ($this->data['seo_url_ratio'] == 3) {
			$health -= 15;
		} elseif ($this->data['seo_url_ratio'] == 2) {
			$health -= 5;
		}

		if ($pending_orders > 20) {
			$health -= 10;
		}

		$this->data['store_health'] = max(0, $health);
	}

	/**
	 * Percentage change of today against yesterday.
	 *
	 * @param float $today
	 * @param float $yesterday
	 *
	 * @return array
	 */
	private function novaDelta($today, $yesterday) {
		if ($yesterday <= 0) {
			return ['show' => false, 'class' => '', 'icon' => '', 'text' => ''];
		}

		$percent = (int)round(($today - $yesterday) / $yesterday * 100);

		return [
			'show'  => true,
			'class' => ($percent >= 0) ? 'is-up' : 'is-down',
			'icon'  => ($percent >= 0) ? 'fa-caret-up' : 'fa-caret-down',
			'text'  => abs($percent) . '%'
		];
	}

	/**
	 * Share of items that are not waiting, as a whole percentage.
	 *
	 * @param int $total
	 * @param int $waiting
	 *
	 * @return int
	 */
	private function novaRatio($total, $waiting) {
		if ($total <= 0) {
			return 100;
		}

		return (int)max(0, min(100, round(($total - $waiting) / $total * 100)));
	}

	public function chart() {
		$this->language->load('common/home');

		$data = [];

		$data['cart'] = [];
		$data['order'] = [];
		$data['customer'] = [];
		$data['xaxis'] = [];

		$data['cart']['label'] = $this->language->get('text_cart');
		$data['order']['label'] = $this->language->get('text_order');
		$data['customer']['label'] = $this->language->get('text_customer');

		$data['cart']['data'] = [];
		$data['order']['data'] = [];
		$data['customer']['data'] = [];

		if (isset($this->request->get['range'])) {
			$range = $this->request->get['range'];
		} else {
			$range = 'month';
		}

		$complete_status_id = $this->config->get('config_complete_status_id');

		switch ($range) {
			case 'day':
				for ($i = 0; $i < 24; $i++) {
					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "order` WHERE order_status_id <> '" . (int)$complete_status_id . "' AND (DATE(date_added) = DATE(NOW()) AND HOUR(date_added) = '" . (int)$i . "') GROUP BY HOUR(date_added) ORDER BY date_added ASC");

					if ($query->num_rows) {
						$data['cart']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['cart']['data'][] = [$i, 0];
					}

					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "order` WHERE order_status_id = '" . (int)$complete_status_id . "' AND (DATE(date_added) = DATE(NOW()) AND HOUR(date_added) = '" . (int)$i . "') GROUP BY HOUR(date_added) ORDER BY date_added ASC");

					if ($query->num_rows) {
						$data['order']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['order']['data'][] = [$i, 0];
					}

					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "customer` WHERE DATE(date_added) = DATE(NOW()) AND HOUR(date_added) = '" . (int)$i . "' GROUP BY HOUR(date_added) ORDER BY date_added ASC");

					if ($query->num_rows) {
						$data['customer']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['customer']['data'][] = [$i, 0];
					}

					$data['xaxis'][] = [$i, date('H', mktime($i, 0, 0, date('n'), date('j'), date('Y')))];
				}
				break;
			default:
			case 'week':
				$date_start = strtotime('-' . date('w') . ' days');

				for ($i = 0; $i < 7; $i++) {
					$date = date('Y-m-d', $date_start + ($i * 86400));

					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "order` WHERE order_status_id <> '" . (int)$complete_status_id . "' AND DATE(date_added) = '" . $this->db->escape($date) . "' GROUP BY DATE(date_added)");

					if ($query->num_rows) {
						$data['cart']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['cart']['data'][] = [$i, 0];
					}

					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "order` WHERE order_status_id = '" . (int)$complete_status_id . "' AND DATE(date_added) = '" . $this->db->escape($date) . "' GROUP BY DATE(date_added)");

					if ($query->num_rows) {
						$data['order']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['order']['data'][] = [$i, 0];
					}

					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "customer` WHERE DATE(date_added) = '" . $this->db->escape($date) . "' GROUP BY DATE(date_added)");

					if ($query->num_rows) {
						$data['customer']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['customer']['data'][] = [$i, 0];
					}

					$data['xaxis'][] = [$i, date('D', strtotime($date))];
				}
				break;
			case 'month':
				for ($i = 1; $i <= date('t'); $i++) {
					$date = date('Y') . '-' . date('m') . '-' . $i;

					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "order` WHERE order_status_id <> '" . (int)$complete_status_id . "' AND (DATE(date_added) = '" . $this->db->escape($date) . "') GROUP BY DAY(date_added)");

					if ($query->num_rows) {
						$data['cart']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['cart']['data'][] = [$i, 0];
					}

					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "order` WHERE order_status_id = '" . (int)$complete_status_id . "' AND (DATE(date_added) = '" . $this->db->escape($date) . "') GROUP BY DAY(date_added)");

					if ($query->num_rows) {
						$data['order']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['order']['data'][] = [$i, 0];
					}

					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "customer` WHERE DATE(date_added) = '" . $this->db->escape($date) . "' GROUP BY DAY(date_added)");

					if ($query->num_rows) {
						$data['customer']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['customer']['data'][] = [$i, 0];
					}

					$data['xaxis'][] = [$i, date('j', strtotime($date))];
				}
				break;
			case 'year':
				for ($i = 1; $i <= 12; $i++) {
					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "order` WHERE order_status_id <> '" . (int)$complete_status_id . "' AND YEAR(date_added) = '" . date('Y') . "' AND MONTH(date_added) = '" . $i . "' GROUP BY MONTH(date_added)");

					if ($query->num_rows) {
						$data['cart']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['cart']['data'][] = [$i, 0];
					}

					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "order` WHERE order_status_id = '" . (int)$complete_status_id . "' AND YEAR(date_added) = '" . date('Y') . "' AND MONTH(date_added) = '" . $i . "' GROUP BY MONTH(date_added)");

					if ($query->num_rows) {
						$data['order']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['order']['data'][] = [$i, 0];
					}

					$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "customer` WHERE YEAR(date_added) = '" . date('Y') . "' AND MONTH(date_added) = '" . $i . "' GROUP BY MONTH(date_added)");

					if ($query->num_rows) {
						$data['customer']['data'][] = [$i, (int)$query->row['total']];
					} else {
						$data['customer']['data'][] = [$i, 0];
					}

					$data['xaxis'][] = [$i, date('M', mktime(0, 0, 0, $i, 1, date('Y')))];
				}
				break;
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));
	}

	public function map() {
		$json = [];

		$this->language->load('common/home');

		$this->load->model('report/sale');

		$results = $this->model_report_sale->getTotalOrdersByCountry();

		foreach ($results as $result) {
			$json[mb_strtolower($result['iso_code_2'], 'UTF-8')] = [
				'orders' => $this->language->get('text_total_order'),
				'total'  => $result['total'],
				'sales'  => $this->language->get('text_total_sale'),
				'amount' => $this->currency->format($result['amount'], $this->config->get('config_currency'))
			];
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function login() {
		if ($this->config->get('config_secure') && !$this->request->isSecure() && strpos(HTTPS_SERVER, 'https') === 0) {
			$this->user->logout();

			return $this->redirect($this->url->link('common/login', '', 'SSL'));
		}

		$route = '';

		if (isset($this->request->get['route'])) {
			$part = explode('/', $this->request->get['route']);

			if (isset($part[0])) {
				$route .= $part[0];
			}

			if (isset($part[1])) {
				$route .= '/' . $part[1];
			}
		}

		$first_ignore = [
			'common/login',
			'common/forgotten',
			'common/reset'
		];

		if (!$this->user->isLogged() && !in_array($route, $first_ignore)) {
			return $this->forward('common/login');
		}

		if (isset($this->request->get['route'])) {
			$ignore = [
				'common/login',
				'common/logout',
				'common/forgotten',
				'common/reset',
				'error/not_found',
				'error/permission'
			];

			$config_ignore = [];

			if ($this->config->get('config_token_ignore')) {
				$raw = $this->config->get('config_token_ignore');

				if (!is_string($raw) || $raw === '') {
					$config_ignore = [];
				} else {
					$config_ignore = json_decode($raw, true);
				}

				if (!is_array($config_ignore)) {
					$config_ignore = [];
				}
			}

			$ignore = array_merge($ignore, $config_ignore);

			if (!in_array($route, $ignore) && (!isset($this->request->get['token']) || !isset($this->session->data['token']) || ($this->request->get['token'] !== $this->session->data['token']))) {
				return $this->forward('common/login');
			}

		} else {
			if (!isset($this->request->get['token']) || !isset($this->session->data['token']) || ($this->request->get['token'] !== $this->session->data['token'])) {
				return $this->forward('common/login');
			}
		}
	}

	public function permission() {
		if (isset($this->request->get['route'])) {
			$route = '';

			$part = explode('/', $this->request->get['route']);

			if (isset($part[0])) {
				$route .= $part[0];
			}

			if (isset($part[1])) {
				$route .= '/' . $part[1];
			}

			$ignore = [
				'common/login',
				'common/logout',
				'common/forgotten',
				'common/notification',
				'common/reset',
				'error/not_found',
				'error/permission'
			];

			if (!in_array($route, $ignore) && !$this->user->hasPermission('access', $route)) {
				return $this->forward('error/permission');
			}
		}
	}
}
