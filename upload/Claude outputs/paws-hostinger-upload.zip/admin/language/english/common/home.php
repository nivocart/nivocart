<?php
// Heading
$_['heading_title']                 = 'Dashboard';

// Text
$_['text_overview']                 = 'Overview';
$_['text_statistics']               = 'Statistics';
$_['text_latest']                   = 'Latest Activity';
$_['text_order_today']              = 'Orders';
$_['text_customer_today']           = 'Customers';
$_['text_sale_today']               = 'Sales';
$_['text_online']                   = 'Online';
$_['text_total_sale']               = 'Total Sales:';
$_['text_total_sale_year']          = 'Total Sales This Year:';
$_['text_total_sale_month']         = 'Total Sales This Month:';
$_['text_total_order']              = 'Total Orders:';
$_['text_total_customer']           = 'Total Customers:';
$_['text_total_customer_approval']  = 'Customers Awaiting Approval:';
$_['text_total_review']             = 'Total Reviews:';
$_['text_total_review_approval']    = 'Reviews Awaiting Approval:';
$_['text_total_affiliate']          = 'Total Affiliates:';
$_['text_total_affiliate_approval'] = 'Affiliates Awaiting Approval:';
$_['text_total_store_products']     = 'Total Products:';
$_['text_day']                      = 'Today';
$_['text_week']                     = 'This Week';
$_['text_month']                    = 'This Month';
$_['text_year']                     = 'This Year';
$_['text_cart']                     = 'Received Orders';
$_['text_order']                    = 'Completed Orders';
$_['text_customer']                 = 'New Customers';
$_['text_topseller']                = 'Top 5 Sellers';
$_['text_topview']                  = 'Top 5 Viewed';
$_['text_topcustomer']              = 'Top 5 Customers';
$_['text_topcountry']               = 'Top Country';
$_['text_download']                 = 'Download';
$_['text_guest']                    = 'Guest';
$_['text_user_log']                 = 'View User Log';
$_['text_seo_url_audit']            = 'Audit SEO URLs';

// Nova dashboard
$_['text_vs_yesterday']             = 'vs yesterday';
$_['text_store_health']             = 'Store Health';
$_['text_overall']                  = 'Overall';
$_['text_orders_hour']              = 'Orders / hour';
$_['text_avg_order']                = 'Avg. order value';
$_['text_system_status']            = 'System Status';
$_['text_moderation']               = 'Moderation Queue';
$_['text_orders_by_hour']           = 'Orders By Hour';
$_['text_live']                     = 'Live';
$_['text_pending_orders']           = 'Pending orders';
$_['text_awaiting_approval']        = 'Awaiting approval';
$_['text_seo_issues']               = 'SEO URL issues';
$_['text_directories']              = 'Folders writeable';
$_['text_customers_approved']       = 'Customers approved';
$_['text_reviews_approved']         = 'Reviews approved';
$_['text_affiliates_approved']      = 'Affiliates approved';
$_['text_orders_processed']         = 'Orders processed';
$_['text_seo_healthy']              = 'SEO URLs healthy';

// Help
$_['help_mail_log']                 = 'Mail log';
$_['help_quote_log']                = 'Quote log';
$_['help_error_log']                = 'Error log';
$_['help_seo_url']                  = 'SEO URL status';

// Tab
$_['tab_map']                       = 'Map';
$_['tab_order']                     = 'Orders';
$_['tab_customer']                  = 'Customers';
$_['tab_review']                    = 'Reviews';
$_['tab_affiliate']                 = 'Affiliates';
$_['tab_return']                    = 'Returns';
$_['tab_upload']                    = 'Uploads';

// Column
$_['column_order']                  = 'Order ID';
$_['column_customer']               = 'Customer';
$_['column_conversion']             = 'Cart Conversion Rate';
$_['column_date_added']             = 'Date Added';
$_['column_status']                 = 'Status';
$_['column_total']                  = 'Total';
$_['column_firstname']              = 'First Name';
$_['column_lastname']               = 'Last Name';
$_['column_name']                   = 'Name';
$_['column_email']                  = 'Email';
$_['column_customer_group']         = 'Customer Group';
$_['column_orders_passed']          = 'Passed Orders';
$_['column_orders_missed']          = 'Missed Orders';
$_['column_product']                = 'Product';
$_['column_author']                 = 'Author';
$_['column_rating']                 = 'Rating';
$_['column_rating_total']           = 'Reviews Total';
$_['column_affiliate']              = 'Affiliate';
$_['column_tracking']               = 'Code';
$_['column_balance']                = 'Balance';
$_['column_approved']               = 'Approved';
$_['column_return_id']              = 'Return ID';
$_['column_return_history']         = 'History';
$_['column_upload_id']              = 'Upload ID';
$_['column_filename']               = 'Filename';
$_['column_sold']                   = 'Sold';
$_['column_viewed']                 = 'Viewed';
$_['column_percent']                = '%';
$_['column_orders']                 = 'Orders';
$_['column_products']               = 'Products';
$_['column_model']                  = 'Model';
$_['column_action']                 = 'Action';

// Entry
$_['entry_range']                   = 'Select Range:';

// Error
$_['error_image']                   = 'Warning: Image directory %s not writeable!';
$_['error_image_cache']             = 'Warning: Image cache directory %s not writeable!';
$_['error_cache']                   = 'Warning: Cache directory %s not writeable!';
$_['error_download']                = 'Warning: Download directory %s not writeable!';
$_['error_upload']                  = 'Warning: Upload directory %s not writeable!';
$_['error_logs']                    = 'Warning: Logs directory %s not writeable!';
$_['error_unserialize']             = 'Warning: Expected a serialized string!';
$_['error_user_log']                = 'Attention: Your <b>User Log</b> has %s records and is becoming very large!';
$_['error_seo_url']                 = 'Attention: SEO URLs are enabled but some catalog entries have problems: <b>%d</b> missing, <b>%d</b> duplicated, <b>%d</b> mistyped and <b>%d</b> orphaned.';
